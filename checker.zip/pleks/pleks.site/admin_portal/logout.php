<?php 
include('dbcon.php');
include('session.php'); 

$result=mysqli_query($con, "select * from users where user_id='$session_id'")or die('Error In Session');
$row=mysqli_fetch_array($result);
$noofuser =  $row['noofuser']-1;
$id=$row['user_id'];
mysqli_query($con, "UPDATE users SET noofuser='$noofuser' WHERE user_id=$id");

 ?>

<?php
session_start();
session_destroy();
echo " <script> window.location.href='../index.php';</script>";
?>