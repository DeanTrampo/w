<?php 
include('dbcon.php');
include('session.php'); 

$result=mysqli_query($con, "select * from users where user_id='$session_id'")or die('Error In Session');
$row=mysqli_fetch_array($result);
$noofcheck=$row['noofcheckallowed'] - $row['noofcheck'];
$username=$row['username'];


 ?>


<html lang="en">
	<head>
		<meta charset="utf-8">
        	
		<title>Pleks Checker</title>
		<meta name="keywords" content="Credit Card Checker">
		<meta name="description" content="Credit Card Checker">
		<meta http-equiv="X-UA-Compatible" content="IE=Edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" href="css/animate.min.css">
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.js" type="text/javascript"></script>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="css/templatemo-style.css">
		<script src="js/jquery.js"></script>
		<script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.singlePageNav.min.js"></script>
		<script src="js/typed.js"></script>
		<script src="js/wow.min.js"></script>
		<script src="js/custom.js"></script>
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	</head>
	
	<body id="top">

		<!-- start preloader -->
		<div class="preloader">
			<div class="sk-spinner sk-spinner-wave">
     	 		<div class="sk-rect1"></div>
       			<div class="sk-rect2"></div>
       			<div class="sk-rect3"></div>
      	 		<div class="sk-rect4"></div>
      			<div class="sk-rect5"></div>
     		</div>
    	</div>
    	<!-- end preloader -->

        <!-- start header -->
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-4 col-xs-12">
                        <p><i class="fa fa-user"></i><span> Welcome: </span><?php echo $username; ?></p>
                    </div>
                    <div class="col-md-5 col-sm-4 col-xs-12">
                      
                    </div>
                    <div class="col-md-2 col-sm-4 col-xs-12">
                        <ul class="social-icon">
							<li><a href="logout.php">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <!-- end header -->
		
		
		
    	<!-- start navigation -->
		<nav class="navbar navbar-default templatemo-nav" role="navigation">
			<div class="container">
				<div class="navbar-header">
					<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="icon icon-bar"></span>
						<span class="icon icon-bar"></span>
						<span class="icon icon-bar"></span>
					</button>
					<a href="http://pleks.site" class="navbar-brand">pleks.site</a>
				</div>
				<div class="collapse navbar-collapse">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="#top">Top</a></li>
						<li><a href="" data-toggle="modal" data-target="#modalLIVECC">Card</a></li>
						<li><a href="" data-toggle="modal" data-target="#modalUSER">User</a></li>
						<li><a href="#team">Team</a></li>
						<li><a href="#service">Checker</a></li>
						<li><a href="#contact">Contact Pleks</a></li>
						<li><a href="">Remaining Credits: <span id="rCredits"> <?php echo $noofcheck; ?></span></a></li>
					</ul>
				</div>
			</div>
		</nav>
		<!-- end navigation -->

		<!-- Modal: LIVE CC -->
		<div class="modal fade" id="modalLIVECC" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
			<div class="modal-dialog modal-md" role="document">
				<div class="modal-content" style="background-color:#424242">
				<!--Header-->
					<div class="modal-header" style="background-color:#0277BD">
						 <button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title" id="myModalLabel"><strong>Live </strong>Cards</h4>
					</div>
				<!--Body-->
				<div class="modal-body">
					<table class="table" >
						<thead>
							<tr>
								<th>Date</th>
								<th>Card</th>
								<th>Message</th>
							</tr>
						</thead>
						
						<tbody>
							<?php
								$result = mysqli_query($con,"SELECT * FROM livecc order by Date Desc");

									while($row = mysqli_fetch_array($result)){
										
											echo '<tr>';
												echo "<td>". $row['Date']."</td>";
												echo "<td>". $row['CC']."</td>";
												echo "<td>". $row['Message']."</td>";
											echo '</tr>';
										
									}
								//mysqli_close($con);
							?>
						</tbody>
					</table>
				</div>
				</div>
			</div>
		</div>
	<!-- Modal: LIVECC -->
	
	<!-- Modal: USER -->
		<div class="modal fade" id="modalUSER" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content" style="background-color:#424242">
				<!--Header-->
					<div class="modal-header" style="background-color:#0277BD">
					    <button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title" id="myModalLabel">List of <strong>Users</strong></h4>
					</div>
				<!--Body-->
				<div class="modal-body">
					<table class="table" >
						<thead>
							<tr>
								<th>Username</th>
								<th>Password</th>
								<th>Type</th>
								<th>Logged </th>
								<th>Users</th>
								<th>Checked</th>
								<th>Cards</th>
								<th colspan="2"><center>Action</center></th>
								
							</tr>
						</thead>
						
						<tbody>
							<?php
								$result1 = mysqli_query($con, "SELECT * FROM users order by type");

									while($row1 = mysqli_fetch_array($result1)){
										
							?>				
									<tr>
										<td> <?php echo $row1['username'];?></td>
										<td> <?php echo $row1['password'];?></td>
										<td> <?php echo $row1['type'];?></td>
										<td> <?php echo $row1['noofuser'];?></td>
										<td> <?php echo $row1['noofuserallowed'];?></td>
										<td> <?php echo $row1['noofcheck'];?></td>
										<td> <?php echo $row1['noofcheckallowed'];?></td>
										<td>
											<a href="./home.php?edit=<?php echo $row1['user_id']; ?>" class="btn btn-warning" >Renew</a>
										</td>
										<td>
											<a href="./home.php?del=<?php echo $row1['user_id']; ?>" class="btn btn-danger">Delete</a>
										</td>
									</tr>
							<?php
									}
								//mysqli_close($con);
							?>
							
						</tbody>
					</table>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-primary btn-md" data-toggle="modal" data-target="#adduser">Add User</button>
				</div>
				</div>
			</div>
		</div>
		<!-- Modal: USER -->
	
		<!-- Modal: USER -->
		<div id="adduser" class="modal fade" role="dialog">
			<div class="modal-dialog">

				<!-- Modal content-->
				<div class="modal-content"style="background-color:#424242" >
					
					<div class="modal-header" style="background-color:#0277BD">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Add <strong>User</strong></h4>
					</div>
				
					<div class="modal-body">
						<form action="" method="post">
							<div class="form-group">
								<label for="username">Username:</label>
								<input name="username" type="text" class="form-control" id="username" autofocus required placeholder="Username">
							</div>
							
							<div class="form-group">
								<label for="password">Password:</label>
								<input name="password" type="text" class="form-control" id="password" required placeholder="Password">
							</div>
							
							<div class="form-group">
								<label for="type">User Type:</label>
								<select class="form-control" id="type" name="type">
									<option value="Administrator">Administrator</option>
									<option value="Demo">Demo</option>
									<option value="Paid">Paid</option>
								</select>
							</div>
							
							<div class="form-group">
								<label for="noofuser">Number of User: </label>
								<input name="noofuser" type="number" class="form-control" id="noofuser" autofocus required placeholder="Number of User">
							</div>
							
							<div class="form-group">
								<label for="noofuserallowed">Number of User allowed:</label>
								<input name="noofuserallowed" type="number" class="form-control" id="noofuserallowed" required placeholder="Number of User allowed">
							</div>
							
							<div class="form-group">
								<label for="noofcheck">Number of Check: </label>
								<input name="noofcheck" type="number" class="form-control" id="noofcheck" autofocus required placeholder="Number of Check">
							</div>
							
							<div class="form-group">
								<label for="noofcheckallowed">Number of Check allowed:</label>
								<input name="noofcheckallowed" type="number" class="form-control" id="noofcheckallowed" required placeholder="Number of Check allowed">
							</div>
							
							<hr>
                            <input type="submit" class="form-control btn-primary" name="add">
    					</form>
					</div>
				</div>
			</div>
		</div>
		<!-- Modal: USER -->
		
						<?php
								if (isset($_POST['add']))
								{
									$username = mysqli_real_escape_string($con, $_POST['username']);
									$password = mysqli_real_escape_string($con, $_POST['password']);
									$type = mysqli_real_escape_string($con, $_POST['type']);
									$noofuser = mysqli_real_escape_string($con, $_POST['noofuser']);
									$noofuserallowed = mysqli_real_escape_string($con, $_POST['noofuserallowed']);
									$noofcheck = mysqli_real_escape_string($con, $_POST['noofcheck']);
									$noofcheckallowed = mysqli_real_escape_string($con, $_POST['noofcheckallowed']);
									mysqli_query($con, "insert into users(username, password, type, noofuser, noofuserallowed, noofcheck, noofcheckallowed) values ('$username', '$password', '$type', '$noofuser', '$noofuserallowed', '$noofcheck', '$noofcheckallowed')");	
									
									echo "<script> alert('Successfully added.')</script>";
									echo " <script> window.location.href='./home.php';</script>";
								}
								
								if (isset($_GET['del'])) {
									$id = $_GET['del'];
									mysqli_query($con, "DELETE FROM users WHERE user_id=$id");
									
									echo "<script> alert('Successfully deleted.')</script>";
									echo " <script> window.location.href='./home.php';</script>";
								}
								
								if (isset($_GET['edit'])) {
									$id = $_GET['edit'];
									mysqli_query($con, "Update users set noofuser='0', noofcheck='0' WHERE user_id=$id");
									
									echo "<script> alert('Successfully renewed.')</script>";
									echo " <script> window.location.href='./home.php';</script>";
								}
						?>
						
						
		
    	<!-- start team -->
    	<section id="team">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-12">
    					<h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s"><span>PLEKS</span> TEAM</h2>
    				</div>
					
					<div class="row">
					
    				<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.3s">
    					<div class="team-wrapper">
    						<img src="images/team-img1.jpg" class="img-responsive" alt="team img 1">
    							<div class="team-des">
    								<h4>RedPenguin</h4>
    								<span>Director / Consultant</span>
    								<p>Rich kid. Lorem ipsum dolor sit amet, consectetur adipiscing elitquisque tempus ac eget diam et laoreet phasellus ut nisi id leo molest.</p>
    							</div>
    					</div>
    				</div>
    				<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.6s">
    					<div class="team-wrapper">
    						<img src="images/team-img2.jpg" class="img-responsive" alt="team img 2">
    							<div class="team-des">
    								<h4>Papa P</h4>
    								<span>Developer</span>
    								<p>Feeling genuis. Lorem ipsum dolor sit amet, consectetur adipiscing elitquisque tempus ac eget diam et laoreet phasellus ut nisi id leo molest.</p>
    							</div>
    					</div>
    				</div>
    				<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.3s">
    					<div class="team-wrapper">
    						<img src="images/team-img3.jpg" class="img-responsive" alt="team img 3">
    							<div class="team-des">
    								<h4>Iamlimited</h4>
    								<span>Explorer</span>
    								<p>Chicks. Lorem ipsum dolor sit amet, consectetur adipiscing elitquisque tempus ac eget diam et laoreet phasellus ut nisi id leo molest.</p>
    							</div>
    					</div>
    				</div>
    				<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.6s">
    					<div class="team-wrapper">
    						<img src="images/team-img4.jpg" class="img-responsive" alt="team img 4">
    							<div class="team-des">
    								<h4>Krung Krung</h4>
    								<span>Explorer</span>
    								<p>Chicks. Lorem ipsum dolor sit amet, consectetur adipiscing elitquisque tempus ac eget diam et laoreet phasellus ut nisi id leo molest.</p>
    							</div>
    					</div>
    				</div>
					
					</div>
					<br>
					<div class="row">
					
    				<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.3s">
    					<div class="team-wrapper">
    						<img src="images/team-img1.jpg" class="img-responsive" alt="team img 1">
    							<div class="team-des">
    								<h4>X-borg</h4>
    								<span>Manager</span>
    								<p>Rich kid. Lorem ipsum dolor sit amet, consectetur adipiscing elitquisque tempus ac eget diam et laoreet phasellus ut nisi id leo molest.</p>
    							</div>
    					</div>
    				</div>
    				<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.6s">
    					<div class="team-wrapper">
    						<img src="images/team-img2.jpg" class="img-responsive" alt="team img 2">
    							<div class="team-des">
    								<h4>[FREE TIER]</h4>
    								<span>Developer</span>
    								<p>Feeling genuis. Lorem ipsum dolor sit amet, consectetur adipiscing elitquisque tempus ac eget diam et laoreet phasellus ut nisi id leo molest.</p>
    							</div>
    					</div>
    				</div>
    				<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.3s">
    					<div class="team-wrapper">
    						<img src="images/team-img3.jpg" class="img-responsive" alt="team img 3">
    							<div class="team-des">
    								<h4>Shang</h4>
    								<span>Explorer</span>
    								<p>Explorer. Lorem ipsum dolor sit amet, consectetur adipiscing elitquisque tempus ac eget diam et laoreet phasellus ut nisi id leo molest.</p>
    							</div>
    					</div>
    				</div>
    				<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.6s">
    					<div class="team-wrapper">
    						<img src="images/team-img4.jpg" class="img-responsive" alt="team img 4">
    							<div class="team-des">
    								<h4>M[s]</h4>
    								<span>Explorer</span>
    								<p>Explorer. Lorem ipsum dolor sit amet, consectetur adipiscing elitquisque tempus ac eget diam et laoreet phasellus ut nisi id leo molest.</p>
    							</div>
    					</div>
    				</div>
					
					</div>
					
    			</div>
    		</div>
    	</section>
    	<!-- end team -->

    	<!-- start service -->
    	<section id="service">
    		<div class="container">
				<h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s"><span>PLEKS</span> CHECKER</h2>
				<div class="row">
					<div class="col-md-1"></div>
					<div class="col-md-10">
						<div class="col-md-12 col-sm-12 col-xs-12 wow fadeInLeft" data-wow-offset="50" data-wow-delay="0.9s">
						<div class="row">
						<h3 class="wow bounceIn collapsed card-link" data-wow-offset="50" data-wow-delay="0.3s" data-toggle="collapse">Cards</h4>
							<textarea class="form-control" rows="4" id="lista" placeholder="XXXXXXXXXXXXXXXX|XX|XXXX|XXX"></textarea>
						</div>
						<br>
						<div class="row">
						<h3 class="wow bounceIn collapsed card-link" data-wow-offset="50" data-wow-delay="0.3s" data-toggle="collapse">Proxy</h4> 
						<a  data-toggle="modal" data-target="#modalPROXY"><p>How to find live proxy?</p></a>
							<textarea class="form-control" rows="1" id="proxy" placeholder="XXX.XXX.XXX.XXX:XXXX"></textarea>
						</div>
						<hr>
						<div class="row">
							<button class="btn btn-primary" style="width: 100%; outline: none;" id="testar" onclick="enviar()" >START</button>
						</div>
						</div>
						
					</div>
					<div class="col-md-1"></div>
				</div>
				
				
				
    			<div class="row">
    					
					<!-- start live -->
					<div class="col-md-1"></div>
					<div class="col-md-10">
						
						<div class="row">						
							<h3 class="wow bounceIn collapsed card-link" data-wow-offset="50" data-wow-delay="0.3s" data-toggle="collapse" href="#CCLive">Approved: <span id="cLive2">0</span></h4>
							<div class="col-md-12 wow fadeIn" data-wow-offset="50" data-wow-delay="0.6s">
								<div id="CCLive" class="collapse" data-parent="#accordion">
									<span id=".aprovadas" class="aprovadas"></span>
								</div>
							</div>
						</div>
						
    					
    				</div>
					<div class="col-md-1"></div>
					<!-- end live -->
				</div>
				<div class="row">
					<!-- start dead -->
					<div class="col-md-1"></div>
					<div class="col-md-10">
						
						<div class="row">						
							<h3 class="dead wow bounceIn collapsed card-link dead" data-wow-offset="50" data-wow-delay="0.3s" data-toggle="collapse" href="#CCDead">Declined: <span id="cDie2">0</span></h4>
							<div class="col-md-12 wow fadeIn" data-wow-offset="50" data-wow-delay="0.6s">
								<div id="CCDead" class="collapse" data-parent="#accordion">
									<span id=".reprovadas" class="reprovadas"></span>
								</div>
							</div>
						</div>
						
    					
    				</div>
					<div class="col-md-1"></div>
					<!-- end dead -->
				
    			</div>
    		</div>
    	</section>
    	<!-- end servie -->

		<!-- Modal: Proxy -->
		<div class="modal fade" id="modalPROXY" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content" style="background-color:#424242">
				<!--Header-->
					<div class="modal-header" style="background-color:#0277BD">
						 <button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title" id="myModalLabel"><strong>Help! </strong></h4>
					</div>
				<!--Body-->
				<div class="modal-body">
					<p align="justify"><strong>STEP 1: </strong>Go to: <a href="https://www.proxy-list.download/HTTPS"> PROXY-LIST</a> or find other sites.</p>
					<p align="justify"><strong>STEP 2: </strong>Copy the list of proxies.</p>
					<p align="justify"><strong>STEP 3: </strong>Go to: <a href="http://normies101.com/proxy/"> Proxy Checker</a></p>
					<p align="justify"><strong>STEP 4: </strong>Paste the copied proxies and click start.</p>
					<br>
					<p align="justify"><strong>Note: </strong>For a better response, please change your proxy whenever 50 Cards are checked.</p>
				</div>
				</div>
			</div>
		</div>
	<!-- Modal: Proxy -->

    	<!-- start contact -->
    	<section id="contact">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-12">
    					<h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s">CONTACT <span>PLEKS</span></h2>
    				</div>
					
					<!-- start Login area -->
    				<div class="col-md-6 col-sm-6 col-xs-12 wow fadeInLeft" data-wow-offset="50" data-wow-delay="0.9s">
    					<form action="#" method="post">
    						<label>NAME</label>
    						<input name="fullname" type="text" class="form-control" id="fullname">
   						  	
                            <label>EMAIL</label>
    						<input name="email" type="email" class="form-control" id="email">
   						  	
                            <label>MESSAGE</label>
    						<textarea name="message" rows="4" class="form-control" id="message"></textarea>
    						
                            <input type="submit" class="form-control">
    					</form>
    				</div>
					
										
    				<div class="col-md-6 col-sm-6 col-xs-12 wow fadeInRight" data-wow-offset="50" data-wow-delay="0.6s">
    					<address>
    						<p class="address-title">OUR ADDRESS</p>
    						<span>Lorem ipsum dolor sit amet, consectetur adipiscing elitquisque tempus ac eget diam et laoreet phasellus ut nisi id leo molestie.</span>
    						<p><i class="fa fa-phone"></i> 935 566 6969</p>
    						<p><i class="fa fa-envelope-o"></i> webmaster@pleks.site</p>
    						<p><i class="fa fa-map-marker"></i> 69 New Walk Roadside, Birdeye View, GO 11020</p>
    					</address>
    					<ul class="social-icon">
    						<li><h4>WE ARE SOCIAL ON</h4></li>
    						<li><a href="#" class="fab fa-facebook"></a></li>
    						<li><a href="#" class="fab fa-discord"></a></li>
						</ul>
    				</div>
    			</div>
    		</div>
    	</section>
    	<!-- end contact -->

        <!-- start copyright -->
        <footer id="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <p class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s">
                       	Copyright &copy; 2020 pleks.site</p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end copyright -->

<!--script Checker-->
<script title="ajax do checker">
    function enviar() {
        var linha = $("#lista").val();
        var linhaenviar = linha.split("\n");
        var total = linhaenviar.length;
        var ap = 0;
        var rp = 0;
		var rCredits; 
        linhaenviar.forEach(function(value, index) {
            setTimeout(
                function() {
					var proxy = $("#proxy").val();
                    $.ajax({
                        url: 'api.php?lista=' + value + '&proxy=' + proxy,
                        type: 'GET',
                        async: true,
                        success: function(resultado) {
                            if (resultado.match("#Aprovada")) {
                                removelinha();
                                ap++;
                                aprovadas(resultado + "");
                            }else {
                                removelinha();
                                rp++;
                                reprovadas(resultado + "");
                            }
							
                            $('#carregadas').html(total);
						
                            var fila = parseInt(ap) + parseInt(rp);
                            $('#cLive').html(ap);
                            $('#cDie').html(rp);
                            $('#total').html(fila);
                            $('#cLive2').html(ap);
                            $('#cDie2').html(rp);
						}
                    });
                }, 5000 * index);
        });
    }
		
    function aprovadas(str) {
        $(".aprovadas").append(str);
    }
    function reprovadas(str) {
        $(".reprovadas").append(str);
    }
    function removelinha() {
        var lines = $("#lista").val().split('\n');
        lines.splice(0, 1);
        $("#lista").val(lines.join("\n"));
    }
	
	function iloveyou(){
	alert('Awan pay api na amo. I love you! @pleks')}
</script>
	<!--end Script Checker-->

	</body>
	
</html>