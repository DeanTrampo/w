

<html lang="en">
	<head>
		<meta charset="utf-8">
        	
		<title>Pleks Checker</title>
		<meta name="keywords" content="Credit Card Checker">
		<meta name="description" content="Credit Card Checker">
		<meta http-equiv="X-UA-Compatible" content="IE=Edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" href="css/animate.min.css">
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.js" type="text/javascript"></script>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="css/templatemo-style.css">
		<script src="js/jquery.js"></script>
		<script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.singlePageNav.min.js"></script>
		<script src="js/typed.js"></script>
		<script src="js/wow.min.js"></script>
		<script src="js/custom.js"></script>
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	</head>
	
	<body id="top">

		<!-- start preloader -->
		<div class="preloader">
			<div class="sk-spinner sk-spinner-wave">
     	 		<div class="sk-rect1"></div>
       			<div class="sk-rect2"></div>
       			<div class="sk-rect3"></div>
      	 		<div class="sk-rect4"></div>
      			<div class="sk-rect5"></div>
     		</div>
    	</div>
    	<!-- end preloader -->

        <!-- start header -->
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-4 col-xs-12">
                        <p><i class="fa fa-user"></i><span> Welcome: </span>Cardero</p>
                    </div>
                    <div class="col-md-5 col-sm-4 col-xs-12">
                      
                    </div>
                    <div class="col-md-2 col-sm-4 col-xs-12">
                        <ul class="social-icon">
							<li><a></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <!-- end header -->

    	<!-- start navigation -->
		<nav class="navbar navbar-default templatemo-nav" role="navigation">
			<div class="container">
				<div class="navbar-header">
					<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="icon icon-bar"></span>
						<span class="icon icon-bar"></span>
						<span class="icon icon-bar"></span>
					</button>
					<a href="index.php" class="navbar-brand">pleks.site</a>
				</div>
				<div class="collapse navbar-collapse">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="#top">Home</a></li>
						<li><a href="#service">Checker</a></li>
					</ul>
				</div>
			</div>
		</nav>
		<!-- end navigation -->


    	<!-- start service -->
    	<section id="service">
    		<div class="container">
				<h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s"><span>PLEKS</span> CHECKER</h2>
				<div class="row">
					<div class="col-md-1"></div>
					<div class="col-md-10">
						
						<div class="col-md-12 col-sm-12 col-xs-12 wow fadeInLeft" data-wow-offset="50" data-wow-delay="0.9s">
						<div class="row">
						<h3 class="wow bounceIn collapsed card-link" data-wow-offset="50" data-wow-delay="0.3s" data-toggle="collapse">Cards</h3>
							<textarea class="form-control" rows="4" id="lista" placeholder="XXXXXXXXXXXXXXXX|XX|XXXX|XXX" autofocus required></textarea>
						</div>
						<br>
						<div class="row">
						<h3 class="wow bounceIn collapsed card-link" data-wow-offset="50" data-wow-delay="0.3s" data-toggle="collapse" required>STRIPE LIVE KEY</h3>
							
							<textarea class="form-control" rows="1" id="sec" placeholder="sk_live_XXxxxxxxxXxxXxX"></textarea>
						</div>
						<hr>
						<div class="row">
							<button class="btn btn-primary" style="width: 100%; outline: none;" id="testar" onclick="enviar()" >START</button>
						</div>
						</div>
						
					</div>
					<div class="col-md-1"></div>
				</div>
				
				
				
    			<div class="row">
    					
					<!-- start live -->
					<div class="col-md-1"></div>
					<div class="col-md-10">
						
						<div class="row">						
							<h3 class="wow bounceIn collapsed card-link" data-wow-offset="50" data-wow-delay="0.3s" data-toggle="collapse" href="#CCLive">Approved: <span id="cLive2">0</span></h4>
							<div class="col-md-12 wow fadeIn" data-wow-offset="50" data-wow-delay="0.6s">
								<div id="CCLive" class="collapse" data-parent="#accordion">
									<span id=".aprovadas" class="aprovadas"></span>
								</div>
							</div>
						</div>
						
    					
    				</div>
					<div class="col-md-1"></div>
					<!-- end live -->
				</div>
				<div class="row">
					<!-- start dead -->
					<div class="col-md-1"></div>
					<div class="col-md-10">
						
						<div class="row">						
							<h3 class="dead wow bounceIn collapsed card-link dead" data-wow-offset="50" data-wow-delay="0.3s" data-toggle="collapse" href="#CCDead">Declined: <span id="cDie2">0</span></h4>
							<div class="col-md-12 wow fadeIn" data-wow-offset="50" data-wow-delay="0.6s">
								<div id="CCDead" class="collapse" data-parent="#accordion">
									<span id=".reprovadas" class="reprovadas"></span>
								</div>
							</div>
						</div>
						
    					
    				</div>
					<div class="col-md-1"></div>
					<!-- end dead -->
				
    			</div>
    		</div>
    	</section>
    	<!-- end servie -->
		

        <!-- start copyright -->
        <footer id="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <p class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s">
                       	Copyright &copy; 2020 pleks.site</p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end copyright -->

<!--script Checker-->
<script title="ajax do checker">
    function enviar() {
        var linha = $("#lista").val();
        var linhaenviar = linha.split("\n");
        var total = linhaenviar.length;
        var ap = 0;
        var rp = 0;
		var rCredits; 
        linhaenviar.forEach(function(value, index) {
            setTimeout(
                function() {
					var sec = $("#sec").val();
                    $.ajax({
                        url: 'api.php?check=' + value + '&sec=' + sec,
                        type: 'GET',
                        async: true,
                        success: function(resultado) {
                            if (resultado.match("#Aprovada")) {
                                removelinha();
                                ap++;
                                aprovadas(resultado + "");
                            }else {
                                removelinha();
                                rp++;
                                reprovadas(resultado + "");
                            }
							
                            $('#carregadas').html(total);
						
                            var fila = parseInt(ap) + parseInt(rp);
                            $('#cLive').html(ap);
                            $('#cDie').html(rp);
                            $('#total').html(fila);
                            $('#cLive2').html(ap);
                            $('#cDie2').html(rp);
						}
                    });
                }, 5000 * index);
        });
    }
		
    function aprovadas(str) {
        $(".aprovadas").append(str);
    }
    function reprovadas(str) {
        $(".reprovadas").append(str);
    }
    function removelinha() {
        var lines = $("#lista").val().split('\n');
        lines.splice(0, 1);
        $("#lista").val(lines.join("\n"));
    }
	
	function iloveyou(){
	alert('Awan pay api na amo. I love you! @pleks')}
</script>
	<!--end Script Checker-->

</body>
	
</html>