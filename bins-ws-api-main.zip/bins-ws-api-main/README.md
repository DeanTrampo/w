# bins-ws-api
API to get BIN Information


### End Point

`/api/{bin}`

### Reboot13


[Telegram](https://telegram.me/reboot13_dev) || [Instagram](https://instagram.com/reboot13_dev) || [Twitter](https://twitter.com/reboot13_dev) || [Youtube](https://youtube.com/krutikraut) || [LinkedIN](https://linkedin.com/in/reboot13)
